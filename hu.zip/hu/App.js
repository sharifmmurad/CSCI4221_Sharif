import React, { useEffect, useState } from "react";
import { View, Text, Switch, Button, Alert, Platform, StyleSheet, ScrollView } from "react-native";
import * as Notifications from "expo-notifications";

// Notification handler — ensures alerts appear while app is open
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});

export default function App() {
  const [enabled, setEnabled] = useState(true);
  const [quietHours, setQuietHours] = useState(false);
  const [granted, setGranted] = useState("unknown");

  useEffect(() => {
    (async () => {
      const settings = await Notifications.getPermissionsAsync();
      setGranted(settings.granted ? "granted" : settings.canAskAgain ? "unknown" : "denied");
    })();
  }, []);

  const requestPermission = async () => {
    const { status } = await Notifications.requestPermissionsAsync();
    const ok = status === "granted";
    setGranted(ok ? "granted" : "denied");
    Alert.alert("Notifications", ok ? "Permission granted" : "Permission denied");
  };

  const sendTest = async () => {
    if (granted !== "granted") return Alert.alert("Notifications", "Grant permission first.");
    await Notifications.scheduleNotificationAsync({
      content: { title: "Test Notification", body: "This is your test message." },
      trigger: { seconds: 5 },
    });
    Alert.alert("Scheduled", "Notification will appear in 5 seconds.");
  };

  const scheduleDaily = async () => {
    if (granted !== "granted") return Alert.alert("Notifications", "Grant permission first.");
    await Notifications.scheduleNotificationAsync({
      content: { title: "Daily Reminder", body: "Check your tasks or budget today." },
      trigger: { hour: 9, minute: 0, repeats: true },
    });
    Alert.alert("Scheduled", "Daily reminder set for 9 AM.");
  };

  const cancelAll = async () => {
    await Notifications.cancelAllScheduledNotificationsAsync();
    Alert.alert("Notifications", "All scheduled notifications canceled.");
  };

  return (
    <ScrollView contentContainerStyle={s.wrap}>
      <Text style={s.h1}>Notification Settings</Text>
      <Text style={s.status}>Permission: {granted}</Text>

      <View style={s.row}>
        <Text style={s.label}>Enable Notifications</Text>
        <Switch value={enabled} onValueChange={setEnabled} />
      </View>

      <View style={s.row}>
        <Text style={s.label}>Quiet Hours (9 PM – 7 AM)</Text>
        <Switch value={quietHours} onValueChange={setQuietHours} />
      </View>

      <View style={s.buttons}>
        <Button title="Request Permission" onPress={requestPermission} />
        <Button title="Send Test in 5s" onPress={sendTest} />
        <Button title="Schedule Daily 9 AM" onPress={scheduleDaily} />
        <Button title="Cancel All" onPress={cancelAll} />
      </View>

      {Platform.OS === "android" && (
        <Text style={s.small}>Android uses channel “default”.</Text>
      )}
    </ScrollView>
  );
}

const s = StyleSheet.create({
  wrap: { padding: 20, gap: 18 },
  h1: { fontSize: 26, fontWeight: "700", marginBottom: 8 },
  status: { fontSize: 16, opacity: 0.7 },
  row: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  label: { fontSize: 17 },
  buttons: { gap: 10, marginTop: 10 },
  small: { fontSize: 13, opacity: 0.6, marginTop: 8 },
});
